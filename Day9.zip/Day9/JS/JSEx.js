function PromptExternalJS() {
    document.getElementById("mainimgid").src= "../Images/1.jpg";
}

function PromptExternalJS1() {
    document.getElementById("mainimgid").src= "../Images/2.jpg";
}

function PromptExternalJS2() {
    document.getElementById("mainimgid").src= "../Images/3.jpg";
}